// implement the Pixel struct and traits below

// implement the Image struct and traits below
