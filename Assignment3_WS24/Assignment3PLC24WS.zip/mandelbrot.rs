// uncomment the code below and implement the functions 

// pub fn check_pixel(c: Complex, max_iterations: usize) -> Option<usize> {
//     // your code here

//     None
// }


// pub fn generate_image(width: usize, height: usize, max_iterations: usize) -> Image {
//     // your code here
    
// }
